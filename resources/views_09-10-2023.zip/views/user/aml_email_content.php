<div style="width:100%; float:left; height:auto; padding:20px;">
    <div style="width:100%; margin-bottom:10px;">
        <?php echo $salutation; ?>, <br/>
        <p> As part of fraud and anti-money laundering legislation we are required to obtain a copy of your identification (a copy of your drivers license or passport is sufficient).</p>

        <p> Please can you reply to us with a copy of your ID (or the Directors & Secretaries ID if you are a limited company).</p>
                
    </div>
    
    <div style="width:100%; height:auto; float:left;">
    <b>Cheers,</b><br>
    Easypayroll Team<br/>
    </div>  
</div>  


