<?php
use App\Http\Controllers\user\P30Controller;
use App\Http\Controllers\user\P30adminController;

Route::get("/user/p30", [P30Controller::class, "p30"]);
Route::get("/user/p30month_manage/{id?}", [P30Controller::class, "p30monthmanage"]);
Route::get("/user/p30_select_month/{id?}", [P30Controller::class, "p30selectmonth"]);
Route::get("/user/p30_review_month/{id?}", [P30Controller::class, "review_month"]);
Route::get(
    "/user/p30_close_create_new_month/{id?}",
    [P30Controller::class, "close_create_new_month"]
);
Route::post(
    "/user/p30_tasklevel_update/{id?}",
    [P30Controller::class, "p30tasklevelupdate"]
);
Route::post(
    "/user/p30_period_update/{id?}",
    [P30Controller::class, "p30periodupdate"]
);
Route::get("/user/pay_p30", [P30Controller::class, "payp30"]);
Route::get("/user/na_p30", [P30Controller::class, "nap30"]);
Route::get("/user/email_p30", [P30Controller::class, "emailp30"]);
Route::post(
    "/user/p30_task_image_upload",
    [P30Controller::class, "p30_task_image_upload"]
);
Route::post(
    "/user/p30_task_automatic_image_upload",
    [P30Controller::class, "p30_task_automatic_image_upload"]
);
Route::get(
    "/user/p30_task_delete_image",
    [P30Controller::class, "p30_task_delete_image"]
);
Route::get(
    "/user/p30_task_delete_xml",
    [P30Controller::class, "p30_task_delete_xml"]
);
Route::get(
    "/user/p30_task_liability_update",
    [P30Controller::class, "task_liability_update"]
);
Route::get(
    "/user/p30_edit_email_unsent_files",
    [P30Controller::class, "p30_edit_email_unsent_files"]
);
Route::post(
    "/user/p30_email_unsent_files",
    [P30Controller::class, "p30_email_unsent_files"]
);
Route::get(
    "/user/p30_task_status_update",
    [P30Controller::class, "p30_task_status_update"]
);
Route::post("/user/p30_report_task", [P30Controller::class, "p30_report_task"]);
Route::post(
    "/user/download_p30_pdf_report",
    [P30Controller::class, "download_p30_pdf_report"]
);
Route::post(
    "/user/import_p30_review_due",
    [P30Controller::class, "import_p30_review_due"]
);
Route::get(
    "/user/download_p30_review",
    [P30Controller::class, "download_p30_review"]
);
Route::post(
    "/user/update_p30_incomplete_status_month",
    [P30Controller::class, "update_p30_incomplete_status_month"]
);
Route::post(
    "/user/update_p30_na_status_month",
    [P30Controller::class, "update_p30_na_status_month"]
);
/***********************************************************/
Route::get("/user/p30_task_leval", [P30adminController::class, "tasklevel"]);
Route::get(
    "/user/deactive_p30_tasklevel/{id?}",
    [P30adminController::class, "deactivetasklevel"]
);
Route::get(
    "/user/active_p30_tasklevel/{id?}",
    [P30adminController::class, "activetasklevel"]
);
Route::post("/user/add_p30_tasklevel/", [P30adminController::class, "addtasklevel"]);
Route::post(
    "/user/edit_p30_tasklevel/{id?}",
    [P30adminController::class, "edittasklevel"]
);
Route::post(
    "/user/update_p30_tasklevel/",
    [P30adminController::class, "updatetasklevel"]
);
Route::get("/user/p30_period", [P30adminController::class, "period"]);
Route::get(
    "/user/deactive_p30_period/{id?}",
    [P30adminController::class, "deactiveperiod"]
);
Route::get(
    "/user/active_p30_period/{id?}",
    [P30adminController::class, "activeperiod"]
);
Route::post("/user/add_p30_period/", [P30adminController::class, "addperiod"]);
Route::post(
    "/user/edit_p30_period/{id?}",
    [P30adminController::class, "editperiod"]
);
Route::post("/user/update_p30_period/", [P30adminController::class, "updateperiod"]);
Route::get(
    "/user/period_sort_order/",
    [P30adminController::class, "period_sort_order"]
);
Route::get("/user/p30_due_date", [P30adminController::class, "duedate"]);
Route::post(
    "/user/update_p30_duedate/",
    [P30adminController::class, "updateduedate"]
);