<?php namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Validator;
use Input;
use DB;
use Response;
use Mail;
use Session;
use PHPMailer;
use Hash;
use Illuminate\Http\Request;
class AdminauthenticateController extends Controller
{
    public function __construct()
    {
        $this->flag = 0;
        $this->middleware("adminredirect", ["except" => "getLogout"]);
        require_once(app_path('Http/helpers.php'));
    }
    public function login()
    {
        return view("admin/login");
    }
    public function postLogin()
    {
        $validator = Validator::make(
            $request->all(),
            [
                "username" => "required",
                "password" => "required",
            ]
        );
        if ($validator->fails()) {
            return redirect("/admin")
                ->withInput($request->all())
                ->with("login_error", $validator->errors());
        } else {
            $username = $request->get("username");
            $password = $request->get("password");
            $admin_details = \App\Models\Admin::first();
            $pin = $admin_details->password;
            if (
                Hash::check($password, $pin) &&
                $username == $admin_details->username
            ) {
                $details = [];
                $admin = \App\Models\Admin::where("id", $admin_details->id)->first();
                if (!empty($admin)) {
                    $details = $admin;
                }
                if (!empty($details)) {
                    $sessn = ["admin_userid" => $details->id];
                    Session::put($sessn);
                    return redirect("/admin/profile");
                } else {
                    return redirect("/admin")
                        ->withInput()
                        ->with("message", "Invalid Username or Password");
                }
            } else {
                return redirect("/admin")
                    ->withInput()
                    ->with("message", "Invalid Username or Password");
            }
        }
    }
    public function adminpostLogin()
    {
        $validator = Validator::make(
            $request->all(),
            [
                "username" => "required",
                "password" => "required",
            ]
        );
        if ($validator->fails()) {
            return redirect("/admin")
                ->withInput($request->all())
                ->with("login_error", $validator->errors());
        } else {
            $username = base64_decode($request->get("username"));
            $password = base64_decode($request->get("password"));
            $admin_details = \App\Models\Admin::first();
            $pin = $admin_details->password;
            if (
                Hash::check($password, $pin) &&
                $username == $admin_details->username
            ) {
                $details = [];
                $admin = \App\Models\Admin::where("id", $admin_details->id)->first();
                if (!empty($admin)) {
                    $details = $admin;
                }
                if (!empty($details)) {
                    $sessn = ["admin_userid" => $details->id];
                    Session::put($sessn);
                    return redirect("/admin/profile");
                } else {
                    return redirect("/admin")
                        ->withInput()
                        ->with("message", "Invalid Username or Password");
                }
            } else {
                return redirect("/admin")
                    ->withInput()
                    ->with("message", "Invalid Username or Password");
            }
        }
    }
}