<?php namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use DB;
use Input;
use Redirect;
use Session;
use Illuminate\Http\Request;
class YearController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('adminauth');
		require_once(app_path('Http/helpers.php'));
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function manageyear(Request $request)
	{
		$year = \App\Models\Year::get();
		return view('admin/year', array('title' => 'Dashboard', 'yearlist' => $year));
	}
	public function deactiveyear(Request $request, $id=""){
		$id = base64_decode($id);
		$deactive =  1;
		 \App\Models\Year::where('year_id', $id)->update(['year_status' => $deactive ]);
		return redirect('admin/manage_year')->with('message','Deactive Success');
	}
	public function activeyear(Request $request, $id=""){
		$id = base64_decode($id);
		$active =  0;
		 \App\Models\Year::where('year_id', $id)->update(['year_status' => $active ]);
		return redirect('admin/manage_year')->with('message','Active Success');
	}
	public function addyear(Request $request){
		$name = $request->get('name');
		$enddate = $request->get('end_date');
		$exp = explode('-',$enddate);
		$date = $exp[2].'-'.$exp[0].'-'.$exp[1];
		$id = \App\Models\Year::insertDetails(['year_name' => $name,'end_date' => $date]);
		 \App\Models\week::insert(['year' => $id,'week' => 1]);
		\App\Models\Month::insert(['year' => $id,'month' => 1]);
		return redirect('admin/manage_year')->with('message','Add Success');
	}
	public function deleteyear(Request $request, $id=""){
		$id = base64_decode($id);
		 \App\Models\Year::where('year_id', $id)->delete();
		return redirect('admin/manage_year')->with('message','Delete Success');
	}
	public function edityear(Request $request, $id=""){
		$id = base64_decode($id);
		$result = \App\Models\Year::where('year_id', $id)->first();
		echo json_encode(array('name' => $result->year_name, 'id' => $result->year_id));
	}
	public function updateyear(Request $request){
		$name = $request->get('name');
		$id = $request->get('id');

		 \App\Models\Year::where('year_id', $id)->update(['year_name' => $name]);
		return redirect('admin/manage_year')->with('message','Update Success');
	}
	public function checkyear(Request $request){		
		$ytext = $request->get('ytext');

		$validate = \App\Models\Year::where('year_name', $ytext)->first();
		
		if(($validate))
		{
			echo 1;
		}
		else{
			echo 0;
		}
	}


}
