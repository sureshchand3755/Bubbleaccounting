<?php namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Schema;
use DB;
use Input;
use Redirect;
use Session;
use Hash;
use Illuminate\Http\Request;
class AdminController extends Controller
{
    /*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/
    /**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
    public function __construct()
    {
        $this->middleware("adminauth");
        require_once(app_path('Http/helpers.php'));
    }
    /**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
    public function manageyear()
    {
        return view("admin/year", ["title" => "Dashboard"]);
    }
    public function profile()
    {
        $admin_details = \App\Models\Admin::where("id", 1)->first();
        $user_details =\App\Models\userLogin::where("userid", 1)->first();
        return view("admin/profile", [
            "admin_details" => $admin_details,
            "user_details" => $user_details,
        ]);
    }
    public function vatprofile()
    {
        $admin_details = \App\Models\Admin::where("id", 1)->first();
        $user_details =\App\Models\userLogin::where("userid", 1)->first();
        return view("admin/vatprofile", [
            "admin_details" => $admin_details,
            "user_details" => $user_details,
        ]);
    }
    public function email_settings()
    {
        $admin_details = \App\Models\Admin::where("id", 1)->first();
        $user_details =\App\Models\userLogin::where("userid", 1)->first();
        return view("admin/emailsettings", [
            "admin_details" => $admin_details,
            "user_details" => $user_details,
        ]);
    }
    public function logout()
    {
        Session::forget("admin_userid");
        return redirect("/admin");
    }
    public function update_admin_setting()
    {
        $username = $request->get("admin_username");
        $currentpassword = $request->get("admin_password");
        $password = Hash::make($request->get("newadmin_password"));
        $passwordd = base64_encode($request->get("newadmin_password"));
        $admin = \App\Models\Admin::first();
        if (Hash::check($currentpassword, $admin->password)) {
            \App\Models\Admin::where("id", 1)->update([
                "username" => $username,
                "password" => $password,
                "pass_base" => $passwordd,
            ]);
            return Redirect::back()->with(
                "message",
                "Settings Updated Successfully"
            );
        } else {
            return Redirect::back()->with(
                "message",
                "Current Password is wrong. please try again later"
            );
        }
    }
    public function update_user_notification()
    {
        $notification = $request->get("user_notification");
        \App\Models\Admin::where("id", 1)->update([
            "notify_message" => $notification,
        ]);
        return Redirect::back()->with(
            "message",
            "Settings Updated Successfully"
        );
    }
    public function update_user_signature()
    {
        $signature = $request->get("user_signature");
        \App\Models\Admin::where("id", 1)->update(["signature" => $signature]);
        return Redirect::back()->with(
            "message",
            "Settings Updated Successfully"
        );
    }
    public function update_user_setting()
    {
        $username = $request->get("user_username");
        $currentpassword = $request->get("user_password");
        $password = Hash::make($request->get("newuser_password"));
        $user =\App\Models\userLogin::first();
        if (Hash::check($currentpassword, $user->password)) {
           \App\Models\userLogin::where("userid", 1)->update([
                "username" => $username,
                "password" => $password,
            ]);
            return Redirect::back()->with(
                "message",
                "Settings Updated Successfully"
            );
        } else {
            return Redirect::back()->with(
                "message",
                "Current Password is wrong. please try again later"
            );
        }
    }
    public function update_email_setting()
    {
        $email = $request->get("email");
        $ccemail = $request->get("ccemail");
        $taskccemail = $request->get("taskccemail");
        $p30ccemail = $request->get("p30ccemail");
        $cmccemail = $request->get("cmccemail");
        $vatccemail = $request->get("vatccemail");
        $deleteemail = $request->get("deleteemail");
        \App\Models\Admin::where("id", 1)->update([
            "email" => $email,
            "cc_email" => $ccemail,
            "task_cc_email" => $taskccemail,
            "p30_cc_email" => $p30ccemail,
            "cm_cc_email" => $cmccemail,
            "vat_cc_email" => $vatccemail,
            "delete_email" => $deleteemail,
        ]);
        return Redirect::back()->with(
            "emailmessage",
            "Email Settings Updated Successfully"
        );
    }
    public function central_locations()
    {
        $central_locations = \App\Models\CentralLocations::first();
        return view("admin/central_locations", [
            "selectval" => $central_locations,
        ]);
    }
    public function update_central_locations()
    {
        $status = $request->get("id");
        \App\Models\Admin::where("id", 1)->update(["central_locations" => $status]);
    }
    public function update_central_locations_form()
    {
        $data["client_management"] = $request->get("client_management");
        $data["invoice_management"] = $request->get("invoice_management");
        $data["client_statements"] = $request->get("client_statements");
        $data["weekly_monthly"] = $request->get("weekly_monthly");
        $data["p30"] = $request->get("p30");
        $data["vat"] = $request->get("vat");
        $data["rct"] = $request->get("rct");
        $data["year_end"] = $request->get("year_end");
        $data["time_location"] = $request->get("time_location");
        \App\Models\CentralLocations::where("id", 1)->update($data);
        return Redirect::back()->with(
            "message",
            "Central Locations Updated Successfully"
        );
    }
    public function manage_cro()
    {
        $cro = \App\Models\Cro_credentials::first();
        return view("admin/manage_cro", ["cro" => $cro]);
    }
    public function update_cro_setting()
    {
        $username = $request->get("username");
        $api_key = $request->get("api_key");
        \App\Models\Cro_credentials::where("id", 1)->update([
            "username" => $username,
            "api_key" => $api_key,
        ]);
        return Redirect::back()->with(
            "emailmessage",
            "CRO Settings Updated Successfully"
        );
    }
    public function clear_opening_balance()
    {
        $client = \App\Models\CMClients::where(
            "practice_code",
            Session::get("user_practice_code")
        )
            ->select(
                "client_id",
                "firstname",
                "surname",
                "company",
                "status",
                "active",
                "id"
            )
            ->orderBy("id", "asc")
            ->get();
        return view("admin/clear_opening_balance", ["clientlist" => $client]);
    }
    public function clear_all_opening_balance()
    {
        $data["opening_balance"] = "";
        $data["opening_date"] = "0000-00-00";
        $dataval["import_balance"] = "";
        $dataval["balance_remaining"] = "";
        \App\Models\OpeningBalance::update($data);
        \App\Models\OpeningBalanceImport::delete();
        \App\Models\InvoiceSystem::update($dataval);
    }
    public function clear_opening_balance_for_client()
    {
        $client_id = $request->get("client_id");
        $data["opening_balance"] = "";
        $data["opening_date"] = "0000-00-00";
        $dataval["import_balance"] = "";
        $dataval["balance_remaining"] = "";
        \App\Models\OpeningBalance::where("client_id", $client_id)->update($data);
        \App\Models\OpeningBalanceImport::where("client_id", $client_id)->delete();
        \App\Models\InvoiceSystem::where("client_id", $client_id)->update($dataval);
    }
    public function clear_receipt_system()
    {
        \App\Models\receipts::truncate();
        receipt\App\Models\NominalCodes::truncate();
        return Redirect::back()->with(
            "message",
            "Receipt System Cleared Successfully"
        );
    }
    public function clear_payment_system()
    {
        \App\Models\payments::truncate();
        payment\App\Models\NominalCodes::truncate();
        return Redirect::back()->with(
            "message",
            "Payment System Cleared SUccessfully"
        );
    }
    public function table_viewer()
    {
        $tables = DB::select("SHOW TABLES");
        $tables = array_map("current", $tables);
        unset($tables[0]);
        unset($tables[5]);
        unset($tables[10]);
        unset($tables[18]);
        unset($tables[19]);
        unset($tables[20]);
        unset($tables[21]);
        unset($tables[22]);
        unset($tables[23]);
        unset($tables[24]);
        unset($tables[25]);
        unset($tables[109]);
        return view("admin/table_viewer", ["tablelist" => $tables]);
    }
    public function get_table_notes()
    {
        $table = $request->get("value");
        $get_notes = \App\Models\tableNotes::where("table_name", $table)->first();
        $notes = "";
        if (count($get_notes)) {
            $notes = $get_notes->notes;
        }
        echo $notes;
    }
    public function update_table_notes()
    {
        $table = $request->get("table");
        $notes = $request->get("notes");
        $get_notes = \App\Models\tableNotes::where("table_name", $table)->first();
        if (count($get_notes)) {
            $data["notes"] = $notes;
            \App\Models\tableNotes::where("id", $get_notes->id)->update($data);
        } else {
            $data["notes"] = $notes;
            $data["table_name"] = $table;
            \App\Models\tableNotes::insert($data);
        }
    }
    public function show_table_viewer()
    {
        $table = $request->get("table_name");
        $page = $request->get("page");
        $limit = 50;
        $offpage = $page - 1;
        $offset = $offpage * 50;
        $fields = DB::getSchemaBuilder()->getColumnListing($table);
        $rows = DB::table($table)
            ->skip($offset)
            ->take($limit)
            ->get();
        $total_array = DB::table($table)->get();
        if (count($total_array)) {
            $total_rows = ceil(count($total_array) / 50);
        } else {
            $total_rows = 0;
        }
        $output = '
		<table class="table own_table_white" style="margin-top: 20px;min-width:100%;float:left">
			<thead>';
        if (count($fields)) {
            foreach ($fields as $field) {
                $output .= "<th>" . $field . "</th>";
            }
        }
        $output .= '</thead>
			<tbody id="table_viewer_tbody">';
        if (count($rows)) {
            foreach ($rows as $row) {
                $output .= "<tr>";
                if (count($fields)) {
                    foreach ($fields as $field) {
                        $output .= "<td>" . $row->$field . "</td>";
                    }
                }
                $output .= "</tr>";
            }
        }
        $output .= '</tbody>
		</table>
		<div class="col-md-12">
		<input type="hidden" name="hidden_page" id="hidden_page" value="1">';
        if ($total_rows > 1) {
            $output .=
                '<input type="button" class="common_black_button common_btn load_more_content" id="load_more_content" value="Load More Content">';
        } else {
            $output .=
                '<input type="button" class="common_black_button common_btn" value="Load More Content" style="display:none">';
        }
        $output .= "</div>";
        echo json_encode(["output" => $output]);
    }
    public function show_table_viewer_append()
    {
        $table = $request->get("table_name");
        $page = $request->get("page");
        $limit = 50;
        $offpage = $page - 1;
        $offset = $offpage * 50;
        $fields = DB::getSchemaBuilder()->getColumnListing($table);
        $rows = DB::table($table)
            ->skip($offset)
            ->take($limit)
            ->get();
        $total_array = DB::table($table)->get();
        if (count($total_array)) {
            $total_rows = ceil(count($total_array) / 50);
        } else {
            $total_rows = 0;
        }
        $output = "";
        if (count($rows)) {
            foreach ($rows as $row) {
                $output .= "<tr>";
                if (count($fields)) {
                    foreach ($fields as $field) {
                        $output .= "<td>" . $row->$field . "</td>";
                    }
                }
                $output .= "</tr>";
            }
        }
        $nextpage = $page + 1;
        if ($total_rows > $page) {
            $show_load_btn = 1;
        } else {
            $show_load_btn = 0;
        }
        echo json_encode([
            "show_load_btn" => $show_load_btn,
            "output" => $output,
        ]);
    }
}