<?php namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use DB;
use Input;
use Redirect;
use Session;
use Schema;
use Hash;
use Illuminate\Http\Request;
class CmsystemController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('adminauth');
		require_once(app_path('Http/helpers.php'));
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */	
	public function cmprofile(Request $request)
	{
		$admin_details = \App\Models\Admin::where('id',1)->first();		
		return view('admin/cm/profile', array('admin_details' => $admin_details));
	}
	public function cm_clients_list(Request $request)
	{
		$client = \App\Models\CMClients::where('practice_code',Session::get('user_practice_code'))->select('client_id', 'firstname', 'surname', 'company', 'email', 'status', 'active', 'id','address1','address2','address3','address4','address5','phone','statement')->get();
		$class = \App\Models\CMClass::where('status', 0)->get();
		return view('admin/cm/clients', array('title' => 'Client Management', 'clientlist' => $client, 'classlist' => $class));
	}
	public function updatecmcrypt(Request $request)
	{
		$old=$request->get('oldcryptpassword');
		$password=Hash::make($request->get('cryptpassword'));

		$admin = \App\Models\Admin::first();
		
		if(Hash::check($old,$admin->cm_crypt))
		{
			\App\Models\Admin::where('id',1)->update(['cm_crypt'=>$password,'view_pass'=>$request->get('cryptpassword')]);
			return Redirect::back()->with('message', 'Settings Updated Successfully');
		}
		else{
			return Redirect::back()->with('message', 'Current Password is wrong. please try again later');
		}
	}
	public function cmclass(Request $request)
	{
		$cmclass = \App\Models\CMClass::get();
		return view('admin/cm/class', array('title' => 'CM Class', 'cmclasslist' => $cmclass));
	}
	public function addclass(Request $request){
		$name = $request->get('name');
		$color = $request->get('color');
		\App\Models\CMClass::insert(['classname' => $name, 'classcolor' => $color]);
		return redirect::back()->with('message','Add Success');
	}
	public function editcmclass(Request $request, $id=""){
		$id = base64_decode($id);
		$result = \App\Models\CMClass::where('id', $id)->first();
		echo json_encode(array('name' => $result->classname, 'color' => $result->classcolor, 'id' => $result->id));
	}

	public function updatecmclass(Request $request){
		$name = $request->get('name');
		$color = $request->get('color');
		$id = $request->get('id');

		
		\App\Models\CMClass::where('id', $id)->update(['classname' => $name, 'classcolor' => $color]);
		return redirect::back()->with('message','Update Success');
	}
	public function deactivecmclass(Request $request, $id=""){
		$id = base64_decode($id);
		$deactive =  1;
		\App\Models\CMClass::where('id', $id)->update(['status' => $deactive ]);
		return redirect::back()->with('message','Deactive Success');
	}
	public function activecmclass(Request $request, $id=""){
		$id = base64_decode($id);
		$active =  0;
		\App\Models\CMClass::where('id', $id)->update(['status' => $active ]);
		return redirect::back()->with('message','Active Success');
	}
	public function cmpaper(Request $request)
	{
		$cmprint = \App\Models\CMPaper::get();
		return view('admin/cm/print', array('title' => 'CM Print', 'cmprintlist' => $cmprint));
	}
	public function addpaper(Request $request){
		$name = $request->get('name');
		$width = $request->get('width');
		$height = $request->get('height');

		$fields = $request->get('fields');
		$fld = '';
		if(($fields))
		{
			foreach($fields as $field)
			{
				if($fld == "")
				{
					$fld = $field;
				}
				else{
					$fld = $fld.','.$field;
				}
			}
		}
		$status = $request->get('set_as_default');
		if($status == 1)
		{
			\App\Models\CMPaper::update(['status' => 0]);
		}
		else{
			$status = 0;
		}
		\App\Models\CMPaper::insert(['papername' => $name, 'width' => $width, 'height' => $height,'labels' => $fld,'status' => $status]);
		return redirect::back()->with('message','Add Success');
	}
	public function editcmpaper(Request $request, $id=""){
		$id = base64_decode($id);
		$result = \App\Models\CMPaper::where('id', $id)->first();
		echo json_encode(array('name' => $result->papername, 'width' => $result->width, 'height' => $result->height, 'fields' => $result->labels, 'status' => $result->status, 'id' => $result->id));
	}

	public function updatecmpaper(Request $request){
		$name = $request->get('name');
		$width = $request->get('width');
		$height = $request->get('height');
		$id = $request->get('id');
		$fields = $request->get('fields');
		$fld = '';
		if(($fields))
		{
			foreach($fields as $field)
			{
				if($fld == "")
				{
					$fld = $field;
				}
				else{
					$fld = $fld.','.$field;
				}
			}
		}

		$status = $request->get('set_as_default');
		if($status == 1)
		{
			\App\Models\CMPaper::update(['status' => 0]);
		}
		
		\App\Models\CMPaper::where('id', $id)->update(['papername' => $name, 'width' => $width, 'height' => $height,'labels' => $fld,'status' => $status]);
		return redirect::back()->with('message','Update Success');
	}

	public function deactivecmpaper(Request $request, $id=""){
		$id = base64_decode($id);
		$deactive =  1;
			\App\Models\CMPaper::update(['status' => 0]);
		\App\Models\CMPaper::where('id', $id)->update(['status' => $deactive ]);
		return redirect::back()->with('message','Deactive Success');
	}
	public function activecmpaper(Request $request, $id=""){
		$id = base64_decode($id);
		$active =  0;
		\App\Models\CMPaper::where('id', $id)->update(['status' => $active ]);
		return redirect::back()->with('message','Active Success');
	}

	public function cmfields(Request $request)
	{
		$cmfield = \App\Models\CMFields::get();
		return view('admin/cm/field', array('title' => 'CM Class', 'cmfieldlist' => $cmfield));
	}

	public function addfield(Request $request){
		$name = $request->get('name_add');
		$field = $request->get('field');
		if($field == 6)
		{
			$options = $request->get('options');
			$value = $request->get('value');
			if(($options))
			{
				$setarray = array();
				foreach($options as $key => $opt)
				{
					$setarray[$opt] = $value[$key];
				}
				$serialize = serialize($setarray);
				\App\Models\CMFields::insert(['name' => $name, 'field' => $field,'options' => $serialize]);
			}
		}
		else{
			\App\Models\CMFields::insert(['name' => $name, 'field' => $field]);
			
		}
		Schema::table('cm_clients', function($table) use ($name)
		{
		    $table->string($name);
		});
		return redirect::back()->with('message','Add Success');
	}

	public function editfield(Request $request, $id=""){
		$id = base64_decode($id);
		$result = \App\Models\CMFields::where('id', $id)->first();
		$optionsval = '';
		if($result->field == 6)
		{
			if($result->options != "")
			{
				$unserialize = unserialize($result->options);
				if(($unserialize))
				{
					$i = 1;
					foreach($unserialize as $key => $opt)
					{
						if($i == count($unserialize))
						{
							$optionsval.='<tr><td><input type="text" class="form-control input-sm" name="options[]" value="'.$key.'" required></td><td><input type="text" class="form-control input-sm" name="value[]" value="'.$opt.'" required></td><td class="action_icon_edit"><a href="javascript:" class="fa fa-plus add_option_edit"></a><a href="javascript:" class="fa fa-minus delete_option_edit"></a></td></tr>';
						}
						else{
							$optionsval.='<tr><td><input type="text" class="form-control input-sm" name="options[]" value="'.$key.'" required></td><td><input type="text" class="form-control input-sm" name="value[]" value="'.$opt.'" required></td><td class="action_icon_edit"><a href="javascript:" class="fa fa-minus delete_option_edit"></a></td></tr>';
						}
						$i++;
					}
				}
			}
		}
		echo json_encode(array('name' => $result->name, 'field' => $result->field, 'id' => $result->id, 'options' => $optionsval));
	}

	public function updatecmfield(Request $request){
		$name = $request->get('name');
		$field = $request->get('field');		
		$id = $request->get('id');

		if($field == 6)
		{
			$options = $request->get('options');
			$value = $request->get('value');
			if(($options))
			{
				$setarray = array();
				foreach($options as $key => $opt)
				{
					$setarray[$opt] = $value[$key];
				}
				$serialize = serialize($setarray);
				$data['name'] = $name;
				$data['field'] = $field;
				$data['options'] = $serialize; 
				\App\Models\CMFields::where('id', $id)->update($data);
			}
		}
		else{
			$data['name'] = $name;
			$data['field'] = $field;
			$data['options'] = ''; 
			\App\Models\CMFields::where('id', $id)->update($data);
		}
		return redirect::back()->with('message','Update Success');
	}
	public function deactivefield(Request $request, $id=""){
		$id = base64_decode($id);
		$deactive =  1;
		\App\Models\CMFields::where('id', $id)->update(['status' => $deactive ]);
		return redirect::back()->with('message','Deactive Success');
	}
	public function activefield(Request $request, $id=""){
		$id = base64_decode($id);
		$active =  0;
		\App\Models\CMFields::where('id', $id)->update(['status' => $active ]);
		return redirect::back()->with('message','Active Success');
	}
	public function cm_client_checkfield(Request $request)
	{
		$field = $request->get('name_add');
		$columns = Schema::getColumnListing('cm_clients');
		
		if(in_array($field,$columns))
			$valid = false;
		else
			$valid = true;
		
		echo json_encode($valid);
		exit;
	}
	public function update_cm_incomplete_status(Request $request)
	{
		$data['cm_incomplete'] = $request->get('value');
		\App\Models\userLogin::where('userid',1)->update($data);
	}
	public function cm_search_clients(Request $request)
	{
		$input = $request->get('input');
		$select = $request->get('select');
		$incomplete_details =\App\Models\userLogin::first();

		$output = '';
		if($select == "address1")
		{
			$clientlist = \App\Models\CMClients::where('practice_code',Session::get('user_practice_code'))->where('address1','like','%'.$input.'%')->orWhere('address2','like','%'.$input.'%')->orWhere('address3','like','%'.$input.'%')->orWhere('address4','like','%'.$input.'%')->orWhere('address5','like','%'.$input.'%')->get();
		}
		else{
			$clientlist = \App\Models\CMClients::where('practice_code',Session::get('user_practice_code'))->where($select,'like','%'.$input.'%')->get();
		}

		$i= 1;
        if(($clientlist)){              
          foreach($clientlist as $client){
            $address = $client->address1.' '.$client->address2.' '.$client->address3.' '.$client->address4.' '.$client->address5;
              if($client->status == 1) { $disabled='disabled'; $style="color:red"; } 
              else{ 
                $disabled='';
                if($client->active != "")
                {
                  $check_color = \App\Models\CMClass::where('id',$client->active)->first();
                  $style="color:#".$check_color->classcolor."";
                }
                else{
                  $style="color:#000";
                }
              } 
	            $output.='<tr class="edit_task '.$disabled.'">
	                <td style="'.$style.'">'.$i.'</td>
	                <td align="left"><a href="javascript:" id="'.base64_encode($client->id).'" class="edit_client" style="'.$style.'">'.$client->client_id.'</a></td>
	                <td align="left"><a href="javascript:" id="'.base64_encode($client->id).'" class="edit_client" style="'.$style.'">'.$client->firstname.'</a></td>
	                <td style="'.$style.'" align="left">'.$client->surname.'</td>
	                <td style="'.$style.'" align="left">'; $output.=($client->company == "")?$client->firstname.' '.$client->surname:$client->company; $output.='</td>
	                <td align="left">
                        <select name="class_select" class="form-control class_select" data-element="'.$client->id.'">';
                              $class = \App\Models\CMClass::where('status', 0)->get();
                              if(($class))
                              {
                                foreach($class as $cls)
                                {
                                  if($cls->id == $client->active) { $selected = 'selected'; } else { $selected = ''; }
                                  $output.='<option value="'.$cls->id.'" '.$selected.'>'.$cls->classname.'</option>';
                                }
                              }
                        $output.='</select>
                    </td>
	                <td style="word-wrap: break-word; white-space:normal; min-width:300px; max-width: 300px;'.$style.'" align="left">'.$address.'</td>
	                <td align="left"><a style="'.$style.'" href="mailto:'.$client->email.'">'.$client->email.'</a></td>
	                <td style="'.$style.'" align="left">'.$client->phone.'</td>
                </tr>';
                $i++;
            }              
        }
        if($i == 1)
        {
          $output.='<tr><td colspan="9" align="center">Empty</td></tr>';
        }
		
		echo $output;
	}
	public function change_cm_client_class(Request $request)
	{
		$value = $request->get('val');
		$id = $request->get('id');
		$class_color = \App\Models\CMClass::where('id',$value)->first();
		\App\Models\CMClients::where('practice_code',Session::get('user_practice_code'))->where('id',$id)->update(['active' => $value]);
		echo $class_color->classcolor;
	}
}
