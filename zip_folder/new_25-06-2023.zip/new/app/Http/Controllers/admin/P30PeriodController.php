<?php namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;
use DB;
use Input;
use Redirect;
use Session;
use Illuminate\Http\Request;
class P30PeriodController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('adminauth');
		require_once(app_path('Http/helpers.php'));
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */
	public function period(Request $request)
	{
		$period = \App\Models\p30Period::get();
		return view('admin/p30/period', array('title' => 'P30 Period', 'periodlist' => $period));
	}
	public function deactiveperiod(Request $request, $id=""){
		$id = base64_decode($id);
		$deactive =  1;
		\App\Models\p30Period::where('id', $id)->update(['status' => $deactive ]);
		return redirect::back()->with('message','Deactive Success');
	}
	public function activeperiod(Request $request, $id=""){
		$id = base64_decode($id);
		$active =  0;
		\App\Models\p30Period::where('id', $id)->update(['status' => $active ]);
		return redirect::back()->with('message','Active Success');
	}
	public function addperiod(Request $request){
		$name = $request->get('name');		
		\App\Models\p30Period::insert(['name' => $name]);
		return redirect::back()->with('message','Add Success');
	}
	public function editperiod(Request $request, $id=""){
		$id = base64_decode($id);
		$result = \App\Models\p30Period::where('id', $id)->first();
		echo json_encode(array('name' => $result->name, 'id' => $result->id));
	}
	public function updateperiod(Request $request){
		$name = $request->get('name');
		$id = $request->get('id');
		
		\App\Models\p30Period::where('id', $id)->update(['name' => $name]);
		return redirect::back()->with('message','Update Success');
	}


}
