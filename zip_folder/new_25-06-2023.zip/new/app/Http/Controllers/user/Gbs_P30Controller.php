<?php namespace App\Http\Controllers\user;
use App\Http\Controllers\Controller;
use DB;
use Input;
use Redirect;
use App\Year;
use App\Week;
use App\Task;
use App\Classified;
use App\User;
use App\Vatclients;
use Session;
use URL;
use PDF;
use Response;
use PHPExcel; 
use PHPExcel_IOFactory;
use PHPExcel_Cell;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Illuminate\Http\Request;
class Gbs_P30Controller extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Welcome Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders the "marketing page" for the application and
	| is configured to only allow guests. Like most of the other sample
	| controllers, you are free to modify or remove it as you desire.
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('userauth');
		date_default_timezone_set("Europe/Dublin");
		require_once app_path("Http/helpers.php");
	}

	/**
	 * Show the application welcome screen to the user.
	 *
	 * @return Response
	 */	
	public function gbs_p30(Request $request)
	{
		$year = \App\Models\Year::where('delete_status',0)->where('year_status', 0)->orderBy('year_name','desc')->get();
		$paye_p30_year = \App\Models\payeP30Year::where('delete_status',0)->where('year_status', 0)->orderBy('year_name','desc')->get();
		return view('user/gbs_p30/month', array('title' => 'Select Year', 'yearlist' => $year, 'paye_p30_year' => $paye_p30_year));
	}
	public function gbs_p30monthmanage(Request $request, $id=""){
		$id = base64_decode($id);
		$year = \App\Models\Year::where('year_id',$id)->first();
		$month = \App\Models\p30Month::where('year', $id)->orderBy('month_id','desc')->get();
		return view('user/gbs_p30/month_manage', array('monthlist' => $month,'year' => $year));
	}
	public function gbs_p30selectmonth($id="")
	{
		$id =base64_decode($id);
		$month_id = \App\Models\p30Month::where('month_id', $id)->first();
		$year_id = $this->year->getdetail($month_id->year);
		$user_year = $year_id->year_id;
		
		$month2 = $month_id->month_id;
		$year2 = $month_id->year;
		$result_task = App\Models\p30task::where('task_year', $year2)->where('task_month', $month2)->get();
		return view('user/gbs_p30/select_month', array('title' => 'gbs_P30 Month Task', 'yearname' => $year_id, 'monthid' => $month_id, 'resultlist' => $result_task));
	}
	public function review_month($id="")
	{
		$month_id = \App\Models\p30Month::where('month_id', $id)->first();
		$current_week = \App\Models\week::orderBy('week_id','desc')->first();
		$current_month = \App\Models\Month::orderBy('month_id','desc')->first();
		$tasks = \App\Models\task::where('task_week',$current_week->week_id)->orWhere('task_month',$current_month->month_id)->groupBy('task_enumber')->get();
		if(($tasks))
		{
			foreach($tasks as $task)
			{
				if($task->task_enumber != "")
				{
					$check_task = App\Models\p30task::where('task_id',$task->task_id)->where('task_month',$id)->count();
					$task_eno = App\Models\p30task::where('task_enumber',$task->task_enumber)->where('task_month',$id)->count();
					if($check_task == 0 && $task_eno == 0)
					{
						$data['task_id'] = $task->task_id;
						$data['task_year'] = $task->task_year;
						$data['task_month'] = $id;
						$data['task_name'] = $task->task_name;
						$data['task_classified'] = $task->task_classified;
						$data['date'] = $task->date;
						$data['task_enumber'] = $task->task_enumber;
						$data['task_email'] = $task->task_email;
						$data['secondary_email'] = $task->secondary_email;
						$data['salutation'] = $task->salutation;
						$data['network'] = $task->network;
						$data['users'] = $task->users;

						$data['task_level'] = $task->tasklevel;
						$data['pay'] = $task->p30_pay;
						$data['email'] = $task->p30_email;

						App\Models\p30task::insert($data); 
					}
				}
			}
		}
		return redirect('user/gbs_p30_select_month/'.base64_encode($id))->with('message', 'Reviewed Successfully.');
	}
	public function close_create_new_month($id="")
	{
		$year = \App\Models\Year::where('year_id', $id)->first();

		$month_id = \App\Models\p30Month::where('year',$year->year_id)->orderBy('month_id','desc')->first();

		if($month_id->month == "12")
		{
			return redirect('user/gbs_p30_select_month/'.base64_encode($month_id->month_id))->with('message', 'Already 12 months has been created in this year. So Please contact admin to create new year.');
		}
		else
		{
			$next_month = $month_id->month + 1;
			$month['year'] = $month_id->year;
			$month['month'] = $next_month;
			$month['month_status'] = 0;

			$new_id = \App\Models\p30Month::insertDetails($month);
			\App\Models\p30Month::where('month_id',$month_id->month_id)->update(['month_closed' => date('Y-m-d H:i:s')]);
		}
		
		$current_week = \App\Models\week::orderBy('week_id','desc')->first();
		$current_month = \App\Models\Month::orderBy('month_id','desc')->first();
		$tasks = \App\Models\task::where('task_week',$current_week->week_id)->orWhere('task_month',$current_month->month_id)->groupBy('task_enumber')->get();
		if(($tasks))
		{
			foreach($tasks as $task)
			{
				if($task->task_enumber != "")
				{
						$data['task_id'] = $task->task_id;
						$data['task_year'] = $task->task_year;
						$data['task_month'] = $new_id;
						$data['task_name'] = $task->task_name;
						$data['task_classified'] = $task->task_classified;
						$data['date'] = $task->date;
						$data['task_enumber'] = $task->task_enumber;
						$data['task_email'] = $task->task_email;
						$data['secondary_email'] = $task->secondary_email;
						$data['salutation'] = $task->salutation;
						$data['network'] = $task->network;
						$data['users'] = $task->users;

						$data['task_level'] = $task->tasklevel;
						$data['pay'] = $task->p30_pay;
						$data['email'] = $task->p30_email;
						
						App\Models\p30task::insert($data); 
				}
			}
		}
		return redirect('user/gbs_p30_select_month/'.base64_encode($new_id))->with('message', 'Month created Successfully.');
	}
	public function gbs_\App\Models\p30tasklevelupdate(Request $request, $id=""){
		$id = $request->get('id');		
		$value = $request->get('value');
		
		App\Models\p30task::where('id', $id)->update(['task_level' => $value]);
	}
	public function gbs_p30periodupdate(Request $request, $id=""){
		$id = $request->get('id');		
		$value = $request->get('value');
		App\Models\p30task::where('id', $id)->update(['task_period' => $value]);
	}
	public function paygbs_p30(Request $request)
	{
		$id = $request->get('id');
		$pay = $request->get('pay');
		App\Models\p30task::where('id',$id)->update(['pay' => $pay]);
	}
	public function nagbs_p30(Request $request)
	{
		$id = $request->get('id');
		$pay = $request->get('na');
		App\Models\p30task::where('id',$id)->update(['na' => $pay]);
	}
	public function emailgbs_p30(Request $request)
	{
		$id = $request->get('id');
		$email = $request->get('email');
		App\Models\p30task::where('id',$id)->update(['email' => $email]);
	}
	public function gbs_p30_task_image_upload(Request $request)
	{
		$total = count($_FILES['image_file']['name']);
		$id = $request->get('hidden_id');
		for($i=0; $i<$total; $i++) {
		 	$filename = $_FILES['image_file']['name'][$i];
			$data_img = App\Models\p30task::where('id',$id)->first();
			
			$tmp_name = $_FILES['image_file']['tmp_name'][$i];
			$upload_dir = 'public/uploads/gbs_p30_task_image';
			if (!file_exists($upload_dir)) {
				mkdir($upload_dir);
			}
			$upload_dir = $upload_dir.'/'.base64_encode($data_img->id);
			if (!file_exists($upload_dir)) {
				mkdir($upload_dir);
			}
			move_uploaded_file($tmp_name, $upload_dir.'/'.$filename);	
			$data['task_id'] = $data_img->id;
			$data['attachment'] = $filename;
			$data['url'] = $upload_dir;
			\App\Models\p30taskAttached::insert($data);
		}
		return redirect('user/gbs_p30_select_month/'.base64_encode($data_img->task_month).'?divid=taskidtr_'.$id);
	}
	public function gbs_p30_task_automatic_image_upload(Request $request)
	{
		$id = $request->get('hidden_id');
	 	$filename = $_FILES['image_file']['name'];
		$data_img = App\Models\p30task::where('id',$id)->first();
		
		$tmp_name = $_FILES['image_file']['tmp_name'];
		$upload_dir = 'public/uploads/gbs_p30_task_xml';
		if (!file_exists($upload_dir)) {
			mkdir($upload_dir);
		}
		$upload_dir = $upload_dir.'/'.base64_encode($data_img->id);
		if (!file_exists($upload_dir)) {
			mkdir($upload_dir);
		}
		move_uploaded_file($tmp_name, $upload_dir.'/'.$filename);
		$data['task_id'] = $data_img->id;
		$data['attachment'] = $filename;
		$data['url'] = $upload_dir;
		\App\Models\p30TaskXml::insert($data);

		$xml=simplexml_load_file($upload_dir.'/'.$filename) or die("Error: Cannot create object");
		$xml_array = $xml->P30;
		
		$paye = floatval($xml_array[0]['PAYE']); 
		$prsi = floatval($xml_array[0]['PRSI']);
		$usc = floatval($xml_array[0]['USC']);
		$lpt = floatval($xml_array[0]['LPT']);

		$count = $paye+$prsi+$usc+$lpt;
		$liability = sprintf('%0.2f', $count);
		App\Models\p30task::where('id',$id)->update(["liability" => $liability]);
		return redirect('user/gbs_p30_select_month/'.base64_encode($data_img->task_month).'?divid=taskidtr_'.$id);
	}
	public function gbs_p30_task_delete_image(Request $request)
	{
		$imgid = $request->get('imgid');
		\App\Models\p30taskAttached::where('id',$imgid)->delete();
	}
	public function gbs_p30_task_delete_xml(Request $request)
	{
		$imgid = $request->get('imgid');
		\App\Models\p30TaskXml::where('id',$imgid)->delete();
	}
	public function task_liability_update(Request $request)
	{
		$value = $request->get('liability');
		$explode = explode(".",$value);
		if(!isset($explode[1]))
		{
			$value = $explode[0].'.00';
		}
		$task_id = $request->get('task_id');
		App\Models\p30task::where('id',$task_id)->update(["liability" => $value]);
	}
	public function gbs_p30_edit_email_unsent_files(Request $request)
	{
		$task_id = $request->get('task_id');
		$result = App\Models\p30task::where('id',$task_id)->first();
		if($result->users != 0)
		{
			$user_details =\App\Models\User::where('user_id',$result->users)->first();
			$from = $user_details->email;
		}
		else{
			$from = '';
		}

		if($result->secondary_email != '')
	    {
	      	$to_email = $result->task_email.', '.$result->secondary_email;
	    }
	    else{
	      	$to_email = $result->task_email;
        }

		$files = '';
		$date = date('d F Y', strtotime($result->last_email_sent));
		$time = date('H:i', strtotime($result->last_email_sent));
		$last_date = $date.' @ '.$time;

		$admin_details = \App\Models\Admin::first();
		$admin_cc = $admin_details->p30_cc_email;

		$data['sentmails'] = $to_email.', '.$admin_cc;
		$data['logo'] = URL::to('public/assets/images/easy_payroll_logo.png');
		$task_details = App\Models\p30task::where('id',$task_id)->first();
		$period = \App\Models\p30Period::where('id',$task_details->task_period)->first();
		$data['salutation'] = $task_details->salutation;
		if($task_details->liability == "")
		{
			$liability_val = '0.00';
		}
		else{
			$liability_val = $task_details->liability;
		}
		$data['liability'] = number_format($liability_val,2, '.', ',');
		$data['pay'] = $task_details->pay;

		  $due_date = \App\Models\p30DueDate::first(); 
	      $month_details = \App\Models\p30Month::where('month_id',$task_details->task_month)->first();
	      $year_details = \App\Models\Year::where('year_id',$month_details->year)->first();
	      
	      if($month_details->month == 1) { $month_name = "February"; }
          if($month_details->month == 2) { $month_name = "March"; }
          if($month_details->month == 3) { $month_name = "April"; }
          if($month_details->month == 4) { $month_name = "May"; }
          if($month_details->month == 5) { $month_name = "June"; }
          if($month_details->month == 6) { $month_name = "July"; }
          if($month_details->month == 7) { $month_name = "August"; }
          if($month_details->month == 8) { $month_name = "September"; }
          if($month_details->month == 9) { $month_name = "October"; }
          if($month_details->month == 10) { $month_name = "November"; }
          if($month_details->month == 11) { $month_name = "December"; }
          if($month_details->month == 12) { $month_name = "January"; }

            if($month_name == "January") { $next_year = $year_details->year_name + 1; 
				$data['due_date'] = $due_date->date.' '.$month_name.' '.$next_year;
			}
			else{
				$data['due_date'] = $due_date->date.' '.$month_name.' '.$year_details->year_name;
			}

			$data['period'] = $period->name;
		$contentmessage = view('user/gbs_p30_email_content', $data)->render();

		
	      $check_attached = \App\Models\p30taskAttached::where('task_id',$task_id)->where('status',0)->get();
	      if(($check_attached))
	      {
	        foreach($check_attached as $attch)
	        {
	            $files.='<p><input type="checkbox" name="check_attachment[]" value="'.$attch->id.'" id="label_'.$attch->id.'" class="check_attachment_cls" checked><label for="label_'.$attch->id.'">'.$attch->attachment.'</label></p>';
	        }
	      }
	      
	      
      	$month_details = \App\Models\p30Month::where('month_id',$result->task_month)->first();
      	$subject = 'Easypayroll.ie : '.$result->task_name.' P30 Submission';

	     echo json_encode(["files" => $files,"html" => $contentmessage,"from" => $from, "to" => $to_email,'subject' => $subject,'last_email_sent' => $last_date]);
	}
	public function gbs_p30_email_unsent_files(Request $request)
	{
		$task_id = $request->get('hidden_email_task_id');
		$det_task = App\Models\p30task::where('id',$task_id)->first();
		$encoded_month_id = base64_encode($det_task->task_month);

		$from = $request->get('from_user');
		$toemails = $request->get('to_user').','.$request->get('cc_unsent');
		$sentmails = $request->get('to_user').', '.$request->get('cc_unsent');
		$subject = $request->get('subject_unsent'); 
		$message = $request->get('message_editor');
		$attachments = $request->get('check_attachment');
		$explode = explode(',',$toemails);
		$data['sentmails'] = $sentmails;

		

		if(($attachments))
		{
			if(($explode))
			{
				foreach($explode as $exp)
				{
					$to = trim($exp);
					$data['logo'] = URL::to('public/assets/images/easy_payroll_logo.png');
					$data['message'] = $message;
					if(($attachments))
					{
						$det = \App\Models\p30taskAttached::where('id',$attachments[0])->first();
					}
					
					$task_details = App\Models\p30task::where('id',$det->task_id)->first();
					$data['salutation'] = $task_details->salutation;
					$data['liability'] = $task_details->liability;
					$data['pay'] = $task_details->pay;

					  $due_date = \App\Models\p30DueDate::first(); 
	                  $month_details = \App\Models\p30Month::where('month_id',$task_details->task_month)->first();
	                  $year_details = \App\Models\Year::where('year_id',$month_details->year)->first();
	                  if($month_details->month == 1) { $month_name = "January"; }
	                  if($month_details->month == 2) { $month_name = "February"; }
	                  if($month_details->month == 3) { $month_name = "March"; }
	                  if($month_details->month == 4) { $month_name = "April"; }
	                  if($month_details->month == 5) { $month_name = "May"; }
	                  if($month_details->month == 6) { $month_name = "June"; }
	                  if($month_details->month == 7) { $month_name = "July"; }
	                  if($month_details->month == 8) { $month_name = "August"; }
	                  if($month_details->month == 9) { $month_name = "September"; }
	                  if($month_details->month == 10) { $month_name = "October"; }
	                  if($month_details->month == 11) { $month_name = "November"; }
	                  if($month_details->month == 12) { $month_name = "December"; }

					$data['due_date'] = $due_date->date.' '.$month_name.' '.$year_details->year_name;

					$contentmessage = view('user/gbs_p30_email_share_paper', $data)->render();
					
					$email = new PHPMailer();
					$email->SetFrom($from); //Name is optional
					$email->Subject   = $subject;
					$email->Body      = $contentmessage;
					$email->IsHTML(true);
					$email->AddAddress( $to );

					if(($attachments))
					{
						foreach($attachments as $attachment)
						{
							$attachment_details = \App\Models\p30taskAttached::where('id',$attachment)->first();
							$path = $attachment_details->url.'/'.$attachment_details->attachment;
							$email->AddAttachment( $path , $attachment_details->attachment );
							\App\Models\p30taskAttached::where('id',$attachment)->update(['status' => 1]);
							$task_id = $attachment_details->task_id;
						}
					}
					$email->Send();	
				}
				$date = date('Y-m-d H:i:s');
				App\Models\p30task::where('id',$task_id)->update(['last_email_sent' => $date]);
				return redirect('user/gbs_p30_select_month/'.$encoded_month_id.'?divid=taskidtr_'.$task_id)->with('message', 'Email Sent Successfully');
			}
			else{
				return redirect('user/gbs_p30_select_month/'.$encoded_month_id.'?divid=taskidtr_'.$task_id)->with('error', 'Email Field is empty so email is not sent');
			}
		}
		else{
			return redirect('user/gbs_p30_select_month/'.$encoded_month_id.'?divid=taskidtr_'.$task_id)->with('error', 'Attachments are empty so Email is not sent');
		}
	}
	public function gbs_p30_task_status_update(Request $request)
	{
		$id = $request->get('id');
		$status = $request->get('status');
		App\Models\p30task::where('id',$id)->update(['task_status' => $status,'updatetime' => date('Y-m-d H:i:s')]);
		$details = \App\Models\task::where('task_id',$id)->first();

      $seperatedate = explode(' ',$details->updatetime);
      $explodedate = explode('-',$seperatedate[0]);
      $explodetime = explode(':',$seperatedate[1]);
      $date = $explodedate[1].'-'.$explodedate[2].'-'.$explodedate[0];
      $time = $explodetime[0].':'.$explodetime[1];

      echo json_encode(["date" => $date,"time" => $time]);
	}
	public function gbs_p30_report_task(Request $request, $id=""){
		$id = $request->get('month_id');
		$month = \App\Models\p30Month::where('month_id', $id)->first();
		$tasks = App\Models\p30task::where('task_month',$month->month_id)->get();
		$output = '';
		if(($tasks))
		{
			foreach($tasks as $task)
			{
				$task_level = \App\Models\p30TaskLevel::where('id',$task->task_level)->first();
				if(($task_level))
				{
					$task_level_val = $task_level->name;
				}	
				else{
					$task_level_val = '';
				}
				$period = \App\Models\p30Period::where('id',$task->task_period)->first();
				if(($period))
				{
					$period_val = $period->name;
				}	
				else{
					$period_val = '';
				}
				if($task->pay == 1) { $pay = 'Yes';} else { $pay = 'No'; }

				$output.='<tr>
				<td style="text-align:center"><input type="checkbox" class="report_task" id="report_'.$task->id.'" data-element="'.$task->id.'"><label for="report_'.$task->id.'">&nbsp</label></td>
				<td>'.$task->task_name.'</td>
				<td>'.$task_level_val.'</td>
				<td>'.$pay.'</td>
				<td>'.$period_val.'</td>
				<td>'.$task->task_email.'</td>
				<td>'.$task->liability.'</td>
				</tr>';
			}
		}
		echo $output;
	}
	public function download_gbs_p30_pdf_report(Request $request)
	{
		$ids = explode(",",$request->get('task_id'));
		$tasks = App\Models\p30task::whereIn('id', $ids)->get();
		$output = '<table style="width:100%; border-collapse:collapse; border:1px solid #000">
			<tr>
				<td style="border:1px solid #000; text-align:left">S.No</td>
				<td style="border:1px solid #000; text-align:left">Task Name</td>
				<td style="border:1px solid #000; text-align:left">Task Level</td>
				<td style="border:1px solid #000; text-align:left">Pay</td>
				<td style="border:1px solid #000; text-align:left">Period</td>
				<td style="border:1px solid #000; text-align:left">EMail</td>
				<td style="border:1px solid #000; text-align:left">Liability</td>
			</tr>';
			$i = 1;
		if(($tasks))
		{
			foreach($tasks as $task)
			{
				$task_level = \App\Models\p30TaskLevel::where('id',$task->task_level)->first();
				if(($task_level))
				{
					$task_level_val = $task_level->name;
				}	
				else{
					$task_level_val = '';
				}
				$period = \App\Models\p30Period::where('id',$task->task_period)->first();
				if(($period))
				{
					$period_val = $period->name;
				}	
				else{
					$period_val = '';
				}
				if($task->pay == 1) { $pay = 'Yes';} else { $pay = 'No'; }

				$output.='<tr>
				<td style="border:1px solid #000; text-align:left">'.$i.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task->task_name.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task_level_val.'</td>
				<td style="border:1px solid #000; text-align:left">'.$pay.'</td>
				<td style="border:1px solid #000; text-align:left">'.$period_val.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task->task_email.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task->liability.'</td>
				</tr>';
				$i++;
			}
		}
		else{
			$output.='<tr><td colspan="7">No Task Found</td></tr>';
		}
		$year = \App\Models\Year::where('year_id',$tasks[0]->task_year)->first();
		$month = \App\Models\p30Month::where('month_id',$tasks[0]->task_month)->first();
		$name = 'P30 Report for the year '.$year->year_name.' - Month '.$month->month.'.pdf';
		$pdf = PDF::loadHTML($output);
		$pdf->setPaper('A4', 'landscape');
		$pdf->save('public/papers/'.$name.'');
		echo $name;
	}
	public function import_gbs_p30_review_due(Request $request)
	{
		$monthid = $request->get('hidden_month_id');
		if($_FILES['import_csv']['name']!='')
		{
			$uploads_dir = dirname($_SERVER["SCRIPT_FILENAME"]).'/public/uploads/importfiles';
			$tmp_name = $_FILES['import_csv']['tmp_name'];
			$name=$_FILES['import_csv']['name'];
			$errorlist = array();
			if(move_uploaded_file($tmp_name, "$uploads_dir/$name")){
				$filepath = $uploads_dir.'/'.$name;
				$objPHPExcel = PHPExcel_IOFactory::load($filepath);
				foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
					$worksheetTitle     = $worksheet->getTitle();
					$highestRow         = $worksheet->getHighestRow(); // e.g. 10
					$highestColumn      = $worksheet->getHighestColumn(); // e.g 'F'
					$highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);
					$nrColumns = ord($highestColumn) - 64;
					
					$height = $highestRow;
					
					$insertrows = array();
					$ernumber_label = $worksheet->getCellByColumnAndRow(4, 1); $ernumber_label = trim($ernumber_label->getValue());
					if($ernumber_label != "Tax Regn./Trader No.")
					{
						return redirect('user/gbs_p30_select_month/'.base64_encode($monthid))->with('error_import', 'You have tried to upload a wrong csv file.');
					}
					else{
						App\Models\p30task::where('task_month',$monthid)->update(['na' => 1]);
						for ($row = 2; $row <= $height; ++ $row) {
							$ernumber = $worksheet->getCellByColumnAndRow(4, $row); $ernumber = trim($ernumber->getValue());
							$task = App\Models\p30task::where('task_month',$monthid)->where('task_enumber',$ernumber)->first();
							if(($task))
							{
								App\Models\p30task::where('id',$task->id)->update(['na' => 2]);
								$sessn=array('p30_session_task_id' => $task->id);
							}
						}
					}
				}
				Session::put($sessn);
				return redirect('user/gbs_p30_select_month/'.base64_encode($monthid))->with('message_import', 'Reviewed successfully.');
			}
		}
	}
	public function download_gbs_p30_review(Request $request)
	{
		$type = $request->get('type');
		$month_id = $request->get('monthid');

		if($type == 1)
		{
			$tasks = App\Models\p30task::where('task_month', $month_id)->where('na',1)->get();
		}
		if($type == 2)
		{
			$tasks = App\Models\p30task::where('task_month', $month_id)->where('na',1)->get();
		}
		if($type == 3)
		{
			$tasks = App\Models\p30task::where('task_month', $month_id)->where('na',2)->get();
		}

		$output = '<table style="width:100%; border-collapse:collapse; border:1px solid #000">
			<tr>
				<td style="border:1px solid #000; text-align:left">S.No</td>
				<td style="border:1px solid #000; text-align:left">Task Name</td>
				<td style="border:1px solid #000; text-align:left">Task Level</td>
				<td style="border:1px solid #000; text-align:left">Pay</td>
				<td style="border:1px solid #000; text-align:left">Period</td>
				<td style="border:1px solid #000; text-align:left">EMail</td>
				<td style="border:1px solid #000; text-align:left">Liability</td>
			</tr>';
			$i = 1;
		if(($tasks))
		{
			foreach($tasks as $task)
			{
				$task_level = \App\Models\p30TaskLevel::where('id',$task->task_level)->first();
				if(($task_level))
				{
					$task_level_val = $task_level->name;
				}	
				else{
					$task_level_val = '';
				}
				$period = \App\Models\p30Period::where('id',$task->task_period)->first();
				if(($period))
				{
					$period_val = $period->name;
				}	
				else{
					$period_val = '';
				}
				if($task->pay == 1) { $pay = 'Yes';} else { $pay = 'No'; }

				$output.='<tr>
				<td style="border:1px solid #000; text-align:left">'.$i.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task->task_name.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task_level_val.'</td>
				<td style="border:1px solid #000; text-align:left">'.$pay.'</td>
				<td style="border:1px solid #000; text-align:left">'.$period_val.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task->task_email.'</td>
				<td style="border:1px solid #000; text-align:left">'.$task->liability.'</td>
				</tr>';
				$i++;
			}
		}
		else{
			$output.='<tr><td colspan="7">No Task Found</td></tr>';
		}
		$year = \App\Models\Year::where('year_id',$tasks[0]->task_year)->first();
		$month = \App\Models\p30Month::where('month_id',$tasks[0]->task_month)->first();

		$name = 'P30 Review Due for the year '.$year->year_name.' - Month '.$month->month.'.pdf';
		$pdf = PDF::loadHTML($output);
		$pdf->setPaper('A4', 'landscape');
		$pdf->save('public/papers/'.$name.'');
		echo $name;
	}
	public function update_gbs_p30_incomplete_status_month(Request $request)
	{
		$data['p30_incomplete'] = $request->get('value');
		\App\Models\userLogin::where('userid',1)->update($data);
	}
}
